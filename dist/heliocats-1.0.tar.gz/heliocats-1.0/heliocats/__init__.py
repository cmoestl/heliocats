# -*- coding: utf-8 -*-

#from .helcats import ICMECAT_EVENT  # noqa: F401
#from .satellites import BEPI, DSCOVR, MES, PSP, SOIO, STA, STB, VEX, WIND  # noqa: F401
#from .spice import SpiceObject as _SpiceObject
#from .util import get_heliosat_paths


__author__ = "Christian Moestl"
__copyright__ = "Copyright (C) 2020 Christian Moestl"
__license__ = "MIT"
__version__ = "1.1"

